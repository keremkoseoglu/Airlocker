using System;

namespace Airlocker
{
	/// <summary>
	/// Summary description for ConfigException.
	/// </summary>
	public class ConfigException: System.Exception
	{
		public ConfigException()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
